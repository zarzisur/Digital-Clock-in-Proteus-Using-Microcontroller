/*
 * GccApplication1.c
 *
 * Created: 5/11/2019 10:13:48 PM
 * Author : Rony
 */ 



/*ABout LCD: LCD has 3 command pin(RS,RW,ENable) and 8 data pins.
RS=Register selection,0 for control register,1 for data register
RW=Read/Write Register,1=read from LCD,0=write to LCD
ENable pin enables data/command to flow

Location setup hint: 0b10000000 or 0x80 is 1st LCD position,for finding LCD position command should be sent keeping MSB of
data pin high.So the remaining 7 pin can hold upto 128 positions.For a barnd new LCD hardware 1st check it`s dispalay
positions.for example:10 th place of LCD is=0b10000000+10;

*/





#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <avr/interrupt.h>


#define F_CPU 1000000UL
#define lcd_data				PORTD
#define direction_lcd_data		DDRD
#define lcd_control				PORTB
#define direction_lcd_control	DDRB
#define enable					2

#define r_w						1
#define rs						0
void send_a_string( char *strng);
void send_character(unsigned char character);
void send_command(unsigned char command);
void check_busy(void);
void peek_a_boo();
void setup_Timer();
void setup_ADC(void);
uint16_t ADC_Read();

volatile uint8_t timerFlag=0;
int main(void)
{
	
	direction_lcd_control |=(1<<enable)|(1<<r_w)|(1<<rs)  ; //Making R/W,RS,enable pin in output mode
	DDRB |=(1<<PINB0) |(1<<PINB1); // to find out how much time is needed for all operation
	
    _delay_ms(20);
	
	send_command(0x01);//clear the screen;
	_delay_ms(2);
	send_command(0x38);// 8 Bit Mode
	_delay_us(50);
	send_command(0b00001110);// cursor Configuration
	_delay_us(50);
	
	/* Replace with your application code */
	 setup_ADC();
     setup_Timer();// 1ms interrupt
	
	// Make a Digital Clock
	send_command(0b10000000);
	send_a_string("Temp:");
	send_command(0b10000000+9);
	send_a_string("DegreeC");
	send_command(0b10000000+67);
	send_a_string(":");
	send_command(0b10000000+71);
	send_a_string(":");
	send_command(0b10000000+75);
	send_a_string(":");
	
	uint16_t sensorValue=0;
	int hour=12, minute=0, sec=1;
	unsigned char am_pm_flag=1;// 0 means am
	unsigned char secondchar[3];
	
	unsigned char minutechar[3];
	
	unsigned char hourchar[3];
	unsigned char sensorchar[4];
	while(1)
	{
			
			
			if(timerFlag==1)
			{
				timerFlag=0;
				
				//Reading ADC data
				sensorValue=0;
				char i;
				for(i=1;i<=10;i++)
				{
					sensorValue=sensorValue+ADC_Read();
				}
				sensorValue=(uint16_t) sensorValue/i;//average
				sensorValue=(uint16_t)(0.48*sensorValue);//converted to degree celsious
				// Send the Sensor Value To LCD
				itoa(sensorValue,sensorchar,10);
				send_command(0b10000000+5);
				send_a_string(sensorchar);
				
				
				
				
				
			// it has been found that the code portion below takes  1.805ms or around 2ms.
							sec++;
							if(sec>=60)
							{
								minute++;
								
								sec=0;
							}
							if(minute>=60)
							{
								hour++;
								minute=0;
							}
							
							if(hour>12)
							{
								hour=1;
							}
							
							if((hour==12) && sec==0 )
							{
								am_pm_flag ^=(1<<0);//toggle AM/PM flag
								
								
							}
							
							itoa(sec,secondchar,10);
							itoa(minute,minutechar,10);
							itoa(hour,hourchar,10);
							if(sec<10)
							{
								send_command(0b10000000+72);
								send_character(' ');
								send_command(0b10000000+73);
								send_a_string(secondchar);
							}
							else
							{
								send_command(0b10000000+72);
								send_a_string(secondchar);
							}
							if(minute<10)
							{
								send_command(0b10000000+68);
								send_character(' ');
								send_command(0b10000000+69);
								send_a_string(minutechar);
							}
							else
							{
								send_command(0b10000000+68);
								send_a_string(minutechar);
							}
							if(hour<10)
							{
								send_command(0b10000000+64);
								send_character(' ');
								send_command(0b10000000+65);
								send_a_string(hourchar);
								
							}
							else
							{
								send_command(0b10000000+64);
								send_a_string(hourchar);
								
							}
							
							if(am_pm_flag==1)
							{
								send_command(0b10000000+76);
								send_a_string("PM");
								
							}
							else if(am_pm_flag==0)
							{
								
								send_command(0b10000000+76);
								send_a_string("AM");
								
							}
							

			}
	
	
	
	}
	
}
	



void check_busy(void)
{
	direction_lcd_data =0x00;
	lcd_control |=(1<<r_w);
	lcd_control &=~(1<<rs);
	while(lcd_data>=0x80)
	{
		peek_a_boo();
	}
	
	direction_lcd_data =0xff;
		
}
void peek_a_boo(void)
{
	lcd_control |=(1<<enable) ; //enable
	asm volatile("nop");
	asm volatile("nop");//wait for lcd to read command or data
	lcd_control &=~(1<<enable);	//disable	
}
void send_command(unsigned char command)
{
	check_busy();
	lcd_data=command;
	  
	lcd_control &=~(1<<r_w|1<<rs);								//Make write mode,register selection to comand mode=0
	
	peek_a_boo();
	lcd_data=0x00;
}
void send_character(unsigned char character)
{
	check_busy();
	lcd_data= character;
	lcd_control &=~(1<<r_w);
	lcd_control |=(1<<rs);
	peek_a_boo();
	lcd_data=0x00;
	
		
}
void send_a_string( char *strng)
{
	while(*strng>0)
	{
		send_character(*strng++);
		
		
	}
		
}
void setup_Timer()
{
	TCCR1B |=(1<<WGM12) |(1<<CS11) |(1<<CS10);//ctc mode,prescaler 64
	OCR1A =15625;//1s time
	TIMSK1 |=(1<<OCIE1A);//output compare a interrupt enable
	sei();//interrupt set
}
ISR(TIMER1_COMPA_vect)
{
	timerFlag=1;
	
}
void setup_ADC(void)
{
	//set ADC0 pin for input
	DDRC &=~(1<<PINC0);
	ADMUX |=(1<<REFS0) ;//Right ADJUSTED, 5V REF
	ADCSRA|=(1<<ADPS1) |(1<<ADPS0);//prescaler 8=125khz
	ADCSRA|=(1<<ADEN);//  enable Adc
	
}
uint16_t ADC_Read()
{
	ADCSRA |=(1<<ADSC);// start conversion
	while((ADCSRA &(1<<ADIF))==0);// polling, after conversion complete ADC interrupt flag becomes 1
	
	
	uint8_t theLow=ADCL;
	uint16_t tenBitValue= (ADCH<<8)| theLow;
	return tenBitValue;
	
}
